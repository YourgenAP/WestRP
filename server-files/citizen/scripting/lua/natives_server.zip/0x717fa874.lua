function Global.SetGameType(gametypeName)
	return _in(0xf90b7469, _ts(gametypeName))
end
