function Global.IsPlayerUsingSuperJump(playerSrc)
	return _in(0xc7d2c20c, _ts(playerSrc), _r)
end
