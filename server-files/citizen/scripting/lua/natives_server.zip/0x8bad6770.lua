function Global.IsAceAllowed(object)
	return _in(0x7ebb9929, _ts(object), _r)
end
