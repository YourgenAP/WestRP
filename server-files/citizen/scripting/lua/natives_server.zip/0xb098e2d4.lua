function Global.EndFindKvp(handle)
	return _in(0xb3210203, handle)
end
